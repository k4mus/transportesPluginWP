<?php

$arregloPaises = array();

$arregloRegiones = array();

$arregloCiudades = array();

$arregloComunas = array();


$query_regiones = "select id as id, descripcion as nombre ,idpais as idpais from regiones";

$query_ciudades = "select id as id, descripcion as nombre ,idregion as idregion from ciudades";

$query_comunas = "select id as id, descripcion as nombre ,idciudad as idciudad from comunas";



$result_paises = mysql_query($query_paises);

$result_regiones = mysql_query($query_regiones);

$result_ciudades = mysql_query($query_ciudades);

$result_comunas = mysql_query($query_comunas);



while ($result_paises && $row = mysql_fetch_object($result_paises))

    $arregloPaises[] = $row;

while ($result_regiones && $row = mysql_fetch_object($result_regiones))

    $arregloRegiones[] = $row;

while ($result_ciudades && $row = mysql_fetch_object($result_ciudades))

    $arregloCiudades[] = $row;

while ($result_comunas && $row = mysql_fetch_object($result_comunas))

    $arregloComunas[] = $row;

    

$paisesJS = json_encode($arregloPaises);

$regionesJS = json_encode($arregloRegiones);

$ciudadesJS = json_encode($arregloCiudades);

$comunasJS = json_encode($arregloComunas);

?>

<html>

<head>

    <script src="js/mochikit.js"></script>
    <script>

        var paises = <?=$paisesJS?>;

        var regiones = <?=$regionesJS?>;

        var ciudades = <?=$ciudadesJS?>;

        var comunas = <?=$comunasJS?>;

        

        function getRegionesByPais(idpais){

            var newArreglo = [];

            for (var i=0;i<regiones.length;i++)

                if (regiones[i].idpais==idpais)

                    newArreglo.push(regiones[i]);

            return newArreglo;

        }

        

        function getCiudadesByRegion(idregion){

            var newArreglo = [];

            for (var i=0;i<ciudades.length;i++)

                if (ciudades[i].idregion==idregion)

                    newArreglo.push(ciudades[i]);

            return newArreglo;

        }

        

        function getComunasByCiudad(idciudad){

            var newArreglo = [];

            for (var i=0;i<comunas.length;i++)

                if (comunas[i].idciudad==idciudad)

                    newArreglo.push(comunas[i]);

            return newArreglo;

        }

        

        function setDataSource(obj,items){

            var arreglo = getElementsByTagAndClassName("option",null,obj);

            for (var i=0;i<arreglo.length;i++)

                removeElement(arreglo[i]);

            if (items!=null)

                for (var i=0;i<items.length;i++)

                        appendChildNodes(obj, OPTION({'value':items[i].id},null,items[i].nombre));    

        }

        

        addLoadEvent(

            function(){

                setDataSource($('pais'),paises);

                

                connect ($('pais'),"onchange", function (elem){

                        setDataSource($('region'),getRegionesByPais(elem.target().value));

                        setDataSource($('ciudad'),null);

                        setDataSource($('comuna'),null);

                    }

                );

                connect ($('region'),"onchange", function (elem){

                        setDataSource($('ciudad'),getCiudadesByRegion(elem.target().value));

                        setDataSource($('comuna'),null);

                    }

                );

                connect ($('ciudad'),"onchange", function (elem){

                        setDataSource($('comuna'),getComunasByCiudad(elem.target().value));

                    }

                );

            });

    </script>

</head>

<body>

 <select id="pais" name="pais"></select>

    


    <select id="region" name="region"/></select>

    


    <select id="ciudad" name="ciudad"/></select>

    


    <select id="comuna" name="comuna"/></select>

    




</body>

</html>


